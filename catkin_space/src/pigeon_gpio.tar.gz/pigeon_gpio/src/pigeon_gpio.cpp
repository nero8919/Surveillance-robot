#include <ros/ros.h>
#include <wiringPi.h>

#define RED_PIN 11
#define BLUE_PIN 10
#define GREEN_PIN 9

int main(int argc, char **argv)
{
    ros::init(argc,argv,"pigeon_gpio");
    ros::NodeHandle nh;

    wiringPiSetupGpio();
    pinMode(RED_PIN,OUTPUT);
    pinMode(BLUE_PIN,OUTPUT);
    pinMode(GREEN_PIN,OUTPUT);
    
    analogWrite(RED_PIN,255);
    analogWrite(BLUE_PIN,255);
    analogWrite(GREEN_PIN,255);
    ROS_INFO("Heloo worold");
}