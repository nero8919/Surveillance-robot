/*
date : 20200921
name :JungHyun Choi
description : get int and float to calculate 
Absolute value of addition , substraction, multiplication, division
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
//declare inputNumber and abs number
    int integerNum , absint;
    float floatNum , absfloat ,tempResult;

//input integer and transform abs
    printf("Enter a integer number : \n");
    scanf("%d",&integerNum);
    absint = abs(integerNum);

//input float and transform abs
    printf("Enter a float number : \n");
    scanf("%f",&floatNum);
    absfloat = fabs(floatNum);

//calculate add, subtract , multiply , divide
    tempResult = absint + absfloat;
    printf("%d + %.1f = %.1f\n",absint,absfloat,tempResult);

    tempResult =  absint - absfloat;
    printf("%d - %.1f = %.1f\n",absint,absfloat,tempResult);

    tempResult =  absint * absfloat;
    printf("%d * %.1f = %.1f\n",absint,absfloat,tempResult);

    tempResult =  absint / absfloat;
    printf("%d / %.1f = %.1f\n",absint,absfloat,tempResult);

}