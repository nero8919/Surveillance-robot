/*
date : 20200921
name :JungHyun Choi
description : get Coefficient of Quadratic equation and get solution
*/

#include <stdio.h>
#include <math.h>

int main(void)
{
    float a,b,c ,Det ,solution_1, solution_2;


    printf("Enter a : ");
    scanf("%f" ,&a);
    printf("Enter b : ");
    scanf("%f" ,&b);
    printf("Enter c : ");
    scanf("%f" ,&c);

    Det = pow(b,2) - (4*a*c);
    if(Det>0){
        printf("There are two different root.\n");
        solution_1 = (-b-sqrt(Det))/(2*a) ;
        solution_2 = (-b+sqrt(Det))/(2*a) ;
        printf("x1 = %.2f, x2 = %.2f\n",solution_1, solution_2);
    }
    else if(Det == 0){
        printf("There is multiple root.\n");
        solution_1 = -b/2*a;
        printf("x = %.2f\n", solution_1);

    }
    else{
        printf("There is no root.\n");

    }

}
