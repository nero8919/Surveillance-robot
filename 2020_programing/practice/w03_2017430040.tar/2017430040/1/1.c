/*
date : 202009021
name : JungHyun Choi
description : Input money and goods which you chose  and cal changes 
*/

#include <stdio.h>  


int main(void)
{   
//declare variables
    int item_100 , item_2000 , item_6000 = 0;
    int enterMoney , changes;

//input variables from User 
    printf("Enter the number of items that cost 100won : ");
    scanf("%d",&item_100);
    printf("Enter the number of items that cost 2000won : ");
    scanf("%d",&item_2000);
    printf("Enter the number of items that cost 6000won : ");
    scanf("%d",&item_6000);
    printf("Enter the amount of money you paid : ");
    scanf("%d",&enterMoney);

//calculate changes from input
    changes = enterMoney -( (100*item_100) + (2000*item_2000) + (6000*item_6000));

//output result
    printf("The change is %d won.\n",changes);
    return 0;
}
