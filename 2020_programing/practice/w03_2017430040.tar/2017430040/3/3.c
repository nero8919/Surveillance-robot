/*
date : 20200921
name :JungHyun Choi
description : calculate pyramid height by get shadow height of a stick
*/

#include <stdio.h>


int main(void)
{
//declare
    float x_0 , x_1 , H_0 , H_1;

//input x_0 (distance from observer to shadow of stick)
    printf("This program calculates of the height of a pyramid.\nInput the distance from an observer to the shadow of a stick (x_0):\n");
    scanf("%f", &x_0);

//input x_1 (distance from observer to shadow of pyramid)
    printf("Input the distance from an observer to the shadow of the pyramid (x_1):\n");
    scanf("%f",&x_1);

//input H_0(stick height)
    printf("Input the height of the stick (H_0):\n");
    scanf("%f",&H_0);
 
 //cal H_1 with Proportional expression
    H_1 = H_0 / x_0 * x_1 ; 
    printf("The height of the pyramid is %.1f\n",H_1);
}