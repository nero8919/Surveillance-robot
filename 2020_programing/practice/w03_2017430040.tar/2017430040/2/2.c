/*
date : 20200921
name :JungHyun Choi
description : input two 1Byte Hexadecimal and output 
Four rules calculation
*/
#include <stdio.h>

int main(void)
{
//declare
    char x , y , z;

//get two hexadecimal 
    printf("Enter two hexadecimal 2 bytes : ");
    scanf("%hhx %hhx", &x ,&y);

//Addition
    z = (int) x + y;
    printf("%d + %d = %d\n", x, y, z);

//subtraction
    z = (int) x - y;
    printf("%d - %d = %d\n", x, y, z);

//subtraction
    z = (int) x * y;
    printf("%d * %d = %d\n", x, y, z);

//division
    z = (int) x / y;  
    printf("%d / %d = %d\n", x, y, z);
}