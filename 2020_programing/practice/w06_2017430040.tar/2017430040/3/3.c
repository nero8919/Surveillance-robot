/*
date : 20201012
name :JungHyun Choi
description :explain code
*/

#include <stdio.h>

int main(){
int a;
int *b = &a;    // 'b' is declared pointer and 'a' adress is stored in b
a = 10;

printf("a: %d\n", a);
   //'a' value  = 10 

printf("*b: %d\n", *b);
 // *'b' mean dereference of 'a' =10

printf("&a: %d\n", &a);
 // &a is adress of 'a' . it is changed every complie
 // ususal it expressed with %p (0x~~~) by 32bit or 64bit
 // but it is %d , so expressed integer without 0x
printf("b: %d\n", b); 
  //b = %a. it is same with upper case 
  // b is pointer having a 'a' adress 
  //and in %p it is expressed Hexadecimal ,but not here 
}