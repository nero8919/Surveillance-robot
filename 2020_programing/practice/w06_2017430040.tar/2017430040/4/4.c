/*
date : 20201012
name :JungHyun Choi
description : arrangement
*/

#include <stdio.h>
#include <stdlib.h>

//declare function reorder the sequence
int *sort(int *arr,int len){
    int i ,j ,temp;
    for(i=0; i<len ; i++){
        for(j=i; j<len ; j++){
            if(arr[i]>arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}


int main(void)
{
//declare    
    int inputNum,i;
    int *arr;
    
//get Number
    printf("Enter a array size: ");
    scanf("%d",&inputNum);
    arr = calloc(inputNum,sizeof(int)); //give a memoryspace

//get intput array
    printf("Elements of the array before sorting: ");
    for(i=0; i<inputNum; i++){
        scanf("%d",&arr[i]);
    } 
    
    sort(arr,inputNum); //use function to reorganize

//print
    printf("Elements of the array after sorting:");
    for(i=0; i<inputNum ; i++){
        printf(" %d", arr[i]);
    }
    printf("\n");

//free memoryspace
    free(arr);


}