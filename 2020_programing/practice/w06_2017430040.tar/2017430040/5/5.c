/*
date : 20201012
name :JungHyun Choi
description : input two set and get inetersection and unionset using array
*/

#include <stdio.h>
#include <stdlib.h>

//reordering function
int *sort(int *arr,int len){
    int i ,j ,temp;
    for(i=0; i<len ; i++){
        for(j=i; j<len ; j++){
            if(arr[i]>arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

//calculate number of intersection
int subset(int *arr1 , int *arr2){
    int i,j,intercount;
    intercount = 0 ;
        for(i=0 ;i<4;i++){
            for(j=0;j<4;j++){
                if(arr1[i]==arr2[j]){
                    intercount++;
                }
            }
        }
        return intercount;

}

//get subset using A-B one by one
int *getsubset(int *arr1 , int *arr2,int subsetNum, int *subset){
    int i,j,k;
    k=0;
    for(i=0 ;i<4;i++){
        for(j=0;j<4;j++){
            if(arr1[i]==arr2[j]){
                subset[k]=arr1[i];
                k++;
                break;   
            }
            
        }
        
    } 

}

//get union set 
int *getUnionset(int *arr1, int *arr2 ,int intercount,int *unionset)
{
    int i , j ,k,flag=0;
    k =0;
    int m = 4;
    int n = 4;
    
    for(i=0;i<m;i++){ 
        unionset[i]=arr1[i]; 
        
        
    } 
    for(i=0;i<n;i++){ 
        flag=0; 
        for(j=0;j<m;j++){ 
            if(arr2[i]==unionset[j]){ 
                flag=1; 
                break; 
            } 
        } 
        if(flag==0){ 
            unionset[4+k]=arr2[i];
            k++;
 
        } 
    }
   
    
}


int main(){
//delcare
    int i,j,k,intercount,unioncount ;
    int *firArr ,*secArr , *intersection , *unionset;
    intercount =0;
    unioncount =0;

//allocate memory
    firArr = calloc(4,sizeof(int));
    secArr = calloc(4,sizeof(int));

//get two input array
    printf("input first set: ");
    for(i = 0 ; i <4 ; i++){
        scanf("%d",&firArr[i]);
    }

    printf("input second set: ");
    for(i = 0 ; i <4 ; i++){
        scanf("%d",&secArr[i]);
    }

//calculate sizeof intersection and unionset 
    intercount = subset(firArr,secArr);
    unioncount = 8- intercount;

    intersection = calloc(intercount ,sizeof(int));
    unionset = calloc(unioncount,sizeof(int));

//first and second set print
    sort(firArr,4);
    printf("The first set: {%d, %d, %d, %d}\n",firArr[0],firArr[1],firArr[2],firArr[3]);

    sort(secArr,4);
    printf("The second set: {%d, %d, %d, %d}\n",secArr[0],secArr[1],secArr[2],secArr[3]);

//assign a value to an intersection array
    getsubset(firArr,secArr,intercount,intersection);   
    sort(intersection,intercount);  //reodering

//print intersection
    printf("The intersection set: {");
    if(intercount!=0){
        for(i=0; i<(intercount-1); i++){
            printf("%d, ",intersection[i]);
        }
        printf("%d",intersection[intercount-1]);
    }
    else printf(" ");
    printf("}\n");

//assign a value to an unionset array
    getUnionset(firArr,secArr,intercount,unionset);
    sort(unionset,unioncount);  //reodering
  
//print union set
    printf("The union set: {");
    for(i=0; i<(unioncount-1); i++){
       printf("%d, ",unionset[i]);
    }
    printf("%d}\n",unionset[unioncount-1]);

//set free memory
    free(firArr);
    free(secArr);
    free(intersection);
    free(unionset);




}
