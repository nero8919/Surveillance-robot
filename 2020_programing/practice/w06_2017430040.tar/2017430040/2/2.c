/*
date : 20201012
name :JungHyun Choi
description : make buterfly move with Double arrangement
i use the fucntion 'move' which check movement and condition

*/
#include <stdio.h>
#include <stdlib.h>

//golbal value checking count
int counter; 

//give movement[2] (x,y) 
int move(int *xymove){
    int direction;
    counter ++;
    direction = rand()%8;
    switch(direction){
            case 0:
                xymove[0] =0;
                xymove[1] =1;
                break;
            case 1:
                xymove[0] =1;
                xymove[1] =1;
                break;
            case 2:
                xymove[0] =1;
                xymove[1] =0;
                break ;               
            case 3:
                xymove[0] =1;
                xymove[1] =-1;
                break;
            case 4:
               xymove[0] =0;
                xymove[1] =-1;
                break;
            case 5:
               xymove[0] =-1;
                xymove[1] =-1;
                break;
            case 6:
               xymove[0] =-1;
                xymove[1] =0;
                break;
            case 7:
               xymove[0] =-1;
                xymove[1] =1;
                break;
               
        }
}



int main(void)
{
//init
    int randomSeed ,i,j, x, y ,checkone;
    int arr[9][9]={} ;
    int xymove[2];
    int maxiumMOvement =100000;
    int (*numPtr)[9] = arr;
    x=4;
    y=4;

 //get randomseed
    printf("Enter a random seed integer: ");
    scanf("%d",&randomSeed);
    srand(randomSeed);
    counter =0;

//checking countermax
    while(counter<maxiumMOvement){
        do{ //use do because it must run onetime
            move(xymove); //use function

            //check boundery condition 
            if(x+xymove[0]<=9 && x+xymove[0]>=0 && y+xymove[1]<=9 &&y+xymove[1]>=0){
                x += xymove[0];
                y += xymove[1];
                
            }
            //else is just give count
  

            checkone=0; //value checking all array when movement is end
            for(i=0;i<9;i++){
                
                for(j=0;j<9;j++){
                    if(arr[i][j]==1){
                        checkone ++;
                    }
                }
            }
            // all array is full then finish
            if(checkone ==81){
                printf("total movement: %d\n",counter);
                return 0;
            }
            

        }while(numPtr[x][y]!=0 && counter<maxiumMOvement);
        numPtr[x][y] = 1;
    }
    
}   