/*
date : 20201012
name : JungHyun Choi
description : get n  and change binarynumber
*/

#include <stdio.h>  
#include <math.h>


int main(void)
{   
//declare variables
    int a , b , i;
    unsigned int inputNum; 
    int arr[32] ={}; //possible 32bit

//get integer from User 
    printf("Enter an unsigned integer: ");
    scanf("%d" ,&inputNum);
 
    printf("result:");   
    
//if input-(2^i) continually
    for(i = 31; i>0 ; i --){
    
        if(pow(2,i)<inputNum){
            inputNum -= pow(2,i);
            arr[31-i]=1;
        }
        else{
            arr[31-i]=0;
        }
    }
//pow error
    arr[31]=inputNum;
    
//print 32bit
    for(i=0; i<32 ; i++){
        if (i%4==0){
            printf(" ");
        }
        printf("%d",arr[i]);

    }
    printf("\n");
}
