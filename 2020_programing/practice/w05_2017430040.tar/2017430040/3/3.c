/*
date : 20201005
name :JungHyun Choi
description : get two positive integer then calculate GCD and LCM
(using Euclid numbering)
*/

#include <stdio.h>

int getGCD(int a, int b);
int getLCM(int a, int b, int GCD);

int main(void)
{
//declare and init
    int a ,b ,temp ,GCD ,LCM;
//get one number 
    printf("Input two integers: ");
    scanf("%d %d",&a ,&b);
    
//make a>b
    if (a<=b){
        temp = a;
        a = b;
        b = temp;
    }
//print GCD and LCM
    GCD = getGCD(a,b);
    LCM = getLCM(a,b,GCD);
    printf("greatest common divisor is %d.\n",GCD);
    printf("least common multiple is %d.\n",LCM);
}

int getGCD(int a ,int b){
    
    // b== 0 means 'a' is GCD , b != 0 means 'b' need division
    return b ? getGCD(b,a%b) :a ; 
}

int getLCM(int a, int b, int GCD){
    return (a / GCD)*(b / GCD)*GCD; 
}