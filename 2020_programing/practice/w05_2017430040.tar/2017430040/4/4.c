/*
date : 20201005
name :JungHyun Choi
description : check that Is this a triangle?
*/

#include <stdio.h>
#include <math.h>

//declare function 
float getLength(float x1, float y1, float x2, float y2);
int isTriangle(float len1, float len2, float len3);


int main(void)
{
//init 
    int x1,x2,x3, y1,y2,y3 ;
    float lenFir, lenSec , lenThr;
    int checkTriangle;

//get point from User
    printf("Input two integers: ");
    scanf("%d %d",&x1,&y1);
    printf("Input two integers: ");
    scanf("%d %d",&x2, &y2);
    printf("Input two integers: ");
    scanf("%d %d",&x3, &y3);

  
//get Distance between each point
    lenFir = getLength(x1, y1 ,x2 ,y2);
    lenSec = getLength(x2, y2 ,x3 ,y3);
    lenThr = getLength(x3, y3 ,x1 ,y1);

//triangle checking
    checkTriangle = isTriangle(lenFir, lenSec , lenThr);

//output the result
    if(checkTriangle==0){
        printf("There is no triangle.\n");
    }
    else{
        printf("There is a triangle.\n");
    }

}

//calculate length between two point 
float getLength(float x1, float y1, float x2, float y2){
    return sqrt(pow((x1-x2),2) + pow((y1-y2),2));
}


//check the posiblity of making triangle 
int isTriangle(float len1, float len2, float len3){
    float temp;
    // make len3 shortest lentgth
    if(len3 > len2){
        temp = len2;
        len2 = len3;
        len3 = temp;
    }
    if(len3>len1){
        temp = len1;
        len1 = len3;
        len3 = temp;
    }
    //make len1 longest length 
    if (len1<len2){
        temp = len1;
        len1 = len2;
        len2 = temp;
    }
 

    if(len1 >= len2+len3){
        return 0;
    }
    else{
        return 1;
    }

}


/*
three point on the one line somethimes give and wrong answer
because float is Approximation of sqrt().
if the point is (1,2)(2,4)(4,8), the distance between two point
are calculated then 5^(1/2) ==> 2.xx , 20^(1/2)==>4.xx , 45^(1/2)==>6.xx
so float length doesnt match with irrational length

*/