/*
date : 20201005
name :JungHyun Choi
description : calculate Binomial coefficient with C(n,k)
*/
#include <stdio.h>

int getBiCoeff(int n ,int c);

int main(void)
{
//declare
    int num, index , BiCoeffSum;

//get two positive integer
    printf("Input two integers: ");
    scanf("%d %d",&num ,&index);    
    
//calculate binomial coefficient with recursive function
    BiCoeffSum = getBiCoeff(num,index);
    printf("binomial coefficient is %d.\n", BiCoeffSum);

}

//recuresively calculate combination
int getBiCoeff(int n, int k){
    if(k==0 || k==n){
        return  1;
    }
    else{
        return getBiCoeff(n-1,k-1) + getBiCoeff(n-1,k);
    }

}