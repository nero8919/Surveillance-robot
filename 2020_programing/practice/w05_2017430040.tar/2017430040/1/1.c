/*
date : 20201005
name : JungHyun Choi
description : make Fibonacci to use Recursive function
*/

#include <stdio.h>  

int Fibonacci(int n);

int main(void)
{   
//declare variables
    int inputNum, fibo; 

//get integer from User 
    printf("Enter a integer: ");
    scanf("%d" ,&inputNum);
    
//calculate the fibonacci function recursively
    fibo = Fibonacci(inputNum);
    printf("number at %d is %d.\n",inputNum,fibo);
}

int Fibonacci(int n){
    if(n==0){
        return 0;
    }
    else if(n==1){
        return 1;

    }
    else{
        return Fibonacci(n-1)+Fibonacci(n-2);
    }
}