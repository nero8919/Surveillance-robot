/*
date : 20201022
name :JungHyun Choi
description : get string and remove empty space
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//get original string and output result string with no space
char *rmSpace(char *str, int size){
  char *result; //using pointer
  int k =0;
  int i =0;
  
  //allocate memory
  result = calloc(size , sizeof(char));

  //checking empty space using ascii code 32
  for(k = 0 ;k< size; k++){
    if(*(str+k) != 32){
      *(result+i) = *(str+k);
      i++;
    }
    if(*(str+k) == '\n'){
      break;
    }
  }
  return result;
}


int main(){

  char str[20];
  char *answer;

  //allocate memory
  answer = calloc(20,sizeof(char));

  //get string
  printf("Input a string: ");
  fgets(str,20,stdin);
  
  //using function 
  answer = rmSpace(str,20);
  
  printf("%s",answer);
  free(answer);

}