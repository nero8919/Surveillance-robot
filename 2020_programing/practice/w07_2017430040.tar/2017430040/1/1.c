/*
date : 20201022
name : JungHyun Choi
description : get two String and check Which one is bigger
*/

#include <stdio.h>  
#include <string.h>


int main(void){
//declare two array
    char str1[20];
    char str2[20];
    int result;

//get two String
    printf("Input str1: ");
    fgets(str1 ,20 , stdin);
    printf("Input str2: ");
    fgets(str2 ,20 , stdin);

//checking dictionary size using strncmp 
    result = strncmp(str1,str2,20);

//result
    if(result>0){
        printf("str1 is bigger than str2.\n");
    }
    else if(result==0){
        printf("str1 is same as str2.\n");
    }
    else{
        printf("str2 is bigger than str1.\n");
    }



}


