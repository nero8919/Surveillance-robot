/*
date : 20201012
name :JungHyun Choi
description :Check if this string is palindrome
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *rmSpace(char *str, int size){
  char *result; //using pointer
  int k =0;
  int i =0;
  
  //allocate memory
  result = calloc(size , sizeof(char));

  //checking empty space using ascii code 32
  for(k = 0 ;k< size; k++){
    if(*(str+k) != 32){
      *(result+i) = *(str+k);
      i++;
    }
    if(*(str+k) == '\n'){
      break;
    }
  }
  return result;
}

//change str --> palindrome
char *isPalindrome(char *str, int strLen){
    char *p = calloc(strLen,sizeof(char));
    int i;

    //Place them opposite each other
    for(i=0 ; i<strLen-1 ; i++){
       *(p+strLen -i -2) = *(str+i) ;
    }
    *(p+strLen-1) = *(str + strLen-1);

    return p;
}

int main(){
  //declare
  char str[20];
  char *noSpaceStr = calloc(20,sizeof(char));
  char *palindrome;
  int length;

  //get string 
  printf("Enter a string: ");
  fgets(str,20,stdin);

  //remove empty space in string
  noSpaceStr = rmSpace(str,20);
  length = strlen(noSpaceStr);

  //allocate memroy and make palidrom using fucntion
  palindrome = calloc(length,sizeof(char));
  palindrome = isPalindrome(noSpaceStr ,length);

  //compare two strings for equality with function strcmp
  printf("reversed string: %s",palindrome);
  if(strcmp(noSpaceStr,palindrome)==0){
      printf("This string is a palindrome\n");
  }
  else{
      printf("This string is not a palindrome\n");
  }

  //free memory
  free(noSpaceStr);
  free(palindrome);

}
