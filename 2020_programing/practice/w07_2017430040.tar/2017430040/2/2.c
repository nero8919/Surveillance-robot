/*
date : 20201022
name :JungHyun Choi
description : change string to capital letter or small letter or not
*/

#include <stdio.h>
#include <stdlib.h>


int main(void)
{
//declare
    char str[20]={};
    int Mode ;
    char *i;

//get string and mode 
    printf("Input string: ");
    fgets(str,20,stdin);

    printf("Input mode: ");
    scanf("%d",&Mode);

//change string capital or small letter using ascii code 
    i=str;
    //small letter
    if(Mode==1){
        while(*i != 10){
            if(*i>64 && *i <91){
                *i +=32;
            }  
           i++;
        }
      
    }
    //capital letter
    else if(Mode == 0){
        while( *i != 10){
            if(*i>96 && *i <123){
                *i -=  32;
            }  
            i++;
        }
     
    }
    
    printf("%s",str);
    
}   