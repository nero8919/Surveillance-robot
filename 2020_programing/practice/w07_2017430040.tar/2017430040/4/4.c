/*
date : 20201022
name :JungHyun Choi
description : get randomSeed and make Determinant automatically and solve it
*/

#include <stdio.h>
#include <stdlib.h>

//declare function calculating determinant
float detCal(int a1,int a2,int a3,int a4){
    return  (float) a1*a4-a2*a3;
}

int main(void)
{
    //declare
    int randomSeed;
    float x,y , Det;
    int arrayL[2][2];
    int arrayR[2] ;

    //get randomseed
    printf("Enter a random seed: ");
    scanf("%d",&randomSeed);

    srand(randomSeed);

    //set randnom number in array
    arrayL[0][0] = rand()%9 +1;
    arrayL[0][1] = rand()%9 +1;
    arrayL[1][0] = rand()%9 +1;
    arrayL[1][1] = rand()%9 +1;
    arrayR[0] = rand()%9 +1;
    arrayR[1] = rand()%9 +1;

    //calculate Det and solution
    Det = detCal(arrayL[0][0],arrayL[0][1],arrayL[1][0],arrayL[1][1]);
    x = detCal(arrayR[0],arrayL[0][1],arrayR[1],arrayL[1][1])/Det;
    y = detCal(arrayL[0][0],arrayR[0],arrayL[1][0],arrayR[1])/Det;

    //print answer
    printf("%d x + %d y = %d\n", arrayL[0][0] ,arrayL[0][1], arrayR[0]);
    printf("%d x + %d y = %d\n", arrayL[1][0], arrayL[1][1], arrayR[1]);

    printf("x = %.3f, y = %.3f\n",x,y);


}

