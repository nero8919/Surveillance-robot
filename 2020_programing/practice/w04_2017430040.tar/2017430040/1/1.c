/*
date : 202009028
name : JungHyun Choi
description : get two  integer and one char to calculate result with switch
*/

#include <stdio.h>  


int main(void)
{   
//declare variables
    int  a,b;
    char operation ; 

//input integer from User 
    printf("Input two integer: ");
    scanf("%d %d",&a,&b);
    printf("Input operation: ");
    scanf(" %c",&operation);

//calculate operation with switch
   switch(operation){
        case '+':
            printf("%d + %d = %d\n",a,b, a+b);
            return 0;
        case '-':
            printf("%d - %d = %d\n",a,b, a-b);
            return 0; 
        case '*':
            printf("%d * %d = %d\n",a,b, a*b);
            return 0;
        case '/':
            printf("%d / %d = %d\n",a,b, a/b);
            return 0;

   }

}
