/*
date : 20200928
name :JungHyun Choi
description : get random seed integer ,find how many times butterfly move
*/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
//init 
    int randomSeed ,x, y ,direction , counter;
    x=0;
    y=0;
    counter =0;

//get integer from User
    printf("Enter a random seed integer: ");
    scanf("%d",&randomSeed);

    srand(randomSeed); //initializing rand function

//check boundary condition with coordinate system
    while(x<10 && x>-10 && y<10 && y>-10){
        direction = rand()%8;
        
        //change direction to point
        switch(direction){
            case 0:
                x++;
                break;
            case 1:
                x++;
                y++;
                break;
            case 2:
                y++;
                break;
            case 3:
                x--;
                y++;
                break;
            case 4:
                y--;
                break;
            case 5:
                x--;
                y--;
                break;
            case 6:
                x--;
                break;
            case 7:
                x--;
                y++;
                break;
        }
        counter ++;
    }
    printf("total movement: %d\n",counter);

}