/*
date : 20200928
name :JungHyun Choi
description : input one number and calculates sum
sum : 2^2 +4^2 + 6^2 + ...(2n)^2
*/

#include <stdio.h>


int main(void)
{
//declare and init
    int sum, inputNum , i ;
    sum =0;
    i=0;
    inputNum =0;
    
//get one number 
    printf("Enter a integer number: ");
    scanf(" %d",&inputNum);
    
//calculate sum of these serise with do ~while
    do{
        if(sum>5000){
            break;
        }
        else{
            if (inputNum<=0)
                break;
            i++;
            sum = sum + (2*i)*(2*i);
        }
    }while(i<inputNum);
    
//print sum
    printf("\"sum\" is %d\n", sum);
    return 0;
}