/*
date : 20200928
name :JungHyun Choi
description : get one number and use Monte Carlo method and solve 
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
//declare
    int numberOfPoint,resolution, i;
    int localPoint=0;
    float PI;
    resolution =1000; // higer resolution more accuracy

//input repeat time
    printf("Enter a integer number: ");
    scanf("%d" ,&numberOfPoint);

//set rand()-->really random with time function
    srand(time(NULL));
    for(i=0; i<numberOfPoint ; i++){  
        
        //init new x,y
        float x = 1.0/resolution;
        float y = 1.0/resolution;

        //get random point
        x = x*((int) rand()%resolution);
        y = y*((int) rand()%resolution);
        
        //distance from (0,0)
        if((x*x)+(y*y)<1.0){
            localPoint++;
        }
    }
//get PI from point ratio
    PI = 4.0*localPoint/numberOfPoint;
    printf("pi is %.3f\n",PI);
}
