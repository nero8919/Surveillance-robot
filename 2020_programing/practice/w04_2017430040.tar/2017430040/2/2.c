/*
date : 20200928
name :JungHyun Choi
description : input positive integer and print the biggest number 
*/
#include <stdio.h>

int main(void)
{
//declare
    int inputNum , minNum, maxNum ;
    minNum=0;
    maxNum=0;

//infinite loop
    while(1){
    printf("input positive integer(negative integer, if you want to exit): ");
    scanf("%d",&inputNum);    
    
//Break loop , input is negative integer
        if(inputNum<0){
            if(maxNum ==0){
                printf("first input is negative integer.\n");
                return 0;
            }
            break;
        }
//positive integer 
        else{ 

            //first init 
            if(minNum ==0){
                minNum = inputNum;
                maxNum = inputNum;
            }

            //compare two integer
            maxNum = inputNum > maxNum ? inputNum : maxNum; 
            minNum = inputNum < minNum ? inputNum : minNum;
        }

    }
    printf("result: maximum = %d, minimum = %d\n" ,maxNum,minNum );

}