/*
date : 20201108
name :JungHyun Choi
description : get two point and calculate with structure pointer
*/
#include <stdio.h>
#include <math.h>

struct Point{
    int x;
    int y;
};

struct Line{
    
    struct Point *p1;
    struct Point *p2;
    float length; 
};

//calculate length between two point 
float getLen(struct Line l){    
    return sqrt(pow(l.p1->x - l.p2->x,2)+pow(l.p1->y - l.p2->y,2));
}

int main(){

    struct Line line;
    struct Point point1, point2;

    printf("Enter point's x, y value: ");
    scanf("%d %d", &point1.x, &point1.y);

    printf("Enter point's x, y value: ");
    scanf("%d %d", &point2.x, &point2.y);

    //connect the struct line's pointer to sturct Point
    line.p1 = &point1;
    line.p2 = &point2;

    printf("Length of line is %.1f\n",getLen(line));
    
}