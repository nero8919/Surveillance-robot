/*
date : 20201108
name :JungHyun Choi
description : sum and avg student data and arrangement
*/
#include <stdio.h>
#include <string.h>

//make student data struct
struct {
    char name[8];
    int math;
    int eng;
    int sci;
    int sum;
    float avg;
} student[10];

int main(){
    int i, j,k ,cnt = 0;

    for(i = 0; i < 10; i++){
        //TODO
        printf("Enter name of student: ");
        scanf("%s",student[i].name); 
        
        // check \n
        for(k=0; k<8;k++){
        
        if(student[i].name[k]=='\n'){
                student[i].name[k]='\0';
                student[i].name[k+1]='0';
            }
        }
        //check end
        if(!strcmp(student[i].name ,"end"))
            break;
        
        //print data
        printf("Enter %s's score of Math: ",student[i].name);
        scanf("%d",&student[i].math);
        printf("Enter %s's score of English: ",student[i].name);
        scanf("%d",&student[i].eng);
        printf("Enter %s's score of Science: ",student[i].name);
        scanf("%d",&student[i].sci);

        //calculate
        student[i].sum=student[i].math+student[i].eng+student[i].sci;
        student[i].avg =(float) student[i].sum/3;

        for(j = 0; j < 40; j++) printf("-");
        printf("\n");
        cnt++;
    }
    printf("Done.\n\n");

    printf("%-10s%-10s%-10s%-10s%-10s%-10s%-7s\n", "No.", "Name", "Math",
     "English", "Science", "Total", "Average");
    for(i = 0; i < cnt; i++){
        //TODO
        printf("%-10d%-10s%-10d%-10d%-10d%-10d%-.1f\n", i, student[i].name , student[i].math , student[i].eng , student[i].sci , student[i].sum , student[i].avg);
    }
} 