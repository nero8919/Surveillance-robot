/*
date : 20201108
name : JungHyun Choi
description : explain the result
*/
#include <stdio.h>

struct {
    int i0;
    double d;
    int i1;
} struct0;

struct {
    int i0;
    int i1;
    double d;
} struct1;

struct {
    char c;
    short s;
} struct2;

struct {
    char c;
    short s;
    int i;
} struct3;

struct {
    char c;
    int i;
    short s;
} struct4;

union {
    char c;
    short s;
    int i;
} union0;

void main(){
    printf("size of struct0 is %ld\n", sizeof(struct0));
    printf("size of struct1 is %ld\n", sizeof(struct1));
    printf("size of struct2 is %ld\n", sizeof(struct2));
    printf("size of struct3 is %ld\n", sizeof(struct3));
    printf("size of struct4 is %ld\n", sizeof(struct4));
    printf("size of union0 is %ld\n", sizeof(union0));
} 
/*
when the memory is assigned in structure, cpu check the biggest data type.
if the small data type came first, then computer add padding bit to read easy
1 , the biggest data is double .so padding bit add 4+4(padding)+8+4+4(padding)
this make cpu read data faser.
2 , sequence is int, int ,double . so the padding bit dont need(4+4 =8 )
result is 4+4+8 =16
3 , the biggest data type is short. 1+1(padding)+2 =4
4 , the biggest data type is  int. char + short =3 . 1 padding bit need
then 1+2+1(padding)+4 =8
5 , same to 4 but sequence is different. so padding bit made differently
1+3(padding)+4+2+2(padding)=12
6 , union have the biggest data type memory. and the member data share space
so union size is 4    
*/