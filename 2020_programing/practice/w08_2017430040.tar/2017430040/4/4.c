/*
date : 20201108
name :JungHyun Choi
description : use ADT stack to make arrangement reversely
*/

#include <stdio.h>
#include <string.h>
#include "stack.h"


int main(){
    //init
    int i;
    char c=0 ,cnt =0;
    struct stack temp_char;
    struct stack output_char;
    reset(&temp_char);
    reset(&output_char);

    //get
    printf("Input string: ");
    fgets(temp_char.s,100,stdin);

    //make char top the length of string 
    temp_char.top = strlen(temp_char.s)-2; //2 is except '/n' 
    //check and reverse
    while(temp_char.top !=EMPTY){
        if(top(&temp_char)==32){
            pop(&temp_char);
        }
        else{
            push(pop(&temp_char),&output_char);
        }
    }
    //print
    printf("Output string: ");
    for(i =0; i<=output_char.top; i++){
        printf("%c",output_char.s[i]);
    }
    printf("\n");
}

