/*
date : 20201012
name :JungHyun Choi
description : use uion to convert 
*/

#include <stdio.h>
#include <string.h>

union int2char {
  unsigned int integer;
  char chr[4];
}uni;

int main(){
  int i , m;
  
  
  printf("Enter unsigned int value: ");
  scanf("%d",&uni.integer);

  //use bit operator to change int to char[4]
  m =uni.integer;
  uni.chr[3] = ( m >>24) & 0xFF;
  uni.chr[2] = ( m >>16) & 0xFF;
  uni.chr[1] = ( m >>8) & 0xFF;
  uni.chr[0] = m & 0xFF;

  printf("You entered: ");
  printf("%s\n",uni.chr);
  

}